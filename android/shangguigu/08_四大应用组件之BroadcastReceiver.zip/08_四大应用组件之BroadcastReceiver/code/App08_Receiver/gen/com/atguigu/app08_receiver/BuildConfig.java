/** Automatically generated file. DO NOT MODIFY */
package com.atguigu.app08_receiver;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}