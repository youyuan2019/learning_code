package com.atguigu.l08_bc;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
/**
 * 测试发送广播的主界面
 * @author 张晓飞
 *
 */
public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}
	
	/*
	 * 发送一般广播
	 */
	public void sendNormalBC(View v) {
		
	}
	
	/*
	 * 发送有序广播
	 */
	public void sendOrderBC(View v) {
		
	}
}
