/** Automatically generated file. DO NOT MODIFY */
package com.atguigu.l08_bc;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}