/** Automatically generated file. DO NOT MODIFY */
package com.atguigu.l08_br;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}