package com.atguigu.l03_component;

public class Person {

	private boolean a;

	public boolean isA() {
		return a;
	}

	public void setA(boolean a) {
		this.a = a;
	}
	
	
}
