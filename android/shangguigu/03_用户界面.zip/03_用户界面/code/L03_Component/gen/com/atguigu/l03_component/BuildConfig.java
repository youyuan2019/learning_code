/** Automatically generated file. DO NOT MODIFY */
package com.atguigu.l03_component;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}