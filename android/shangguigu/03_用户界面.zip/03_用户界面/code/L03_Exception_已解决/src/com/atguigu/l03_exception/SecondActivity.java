package com.atguigu.l03_exception;

import android.app.Activity;
import android.os.Bundle;

/**
 * 界面二
 * @author 张晓飞
 *
 */
public class SecondActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_secend);
	}
}
