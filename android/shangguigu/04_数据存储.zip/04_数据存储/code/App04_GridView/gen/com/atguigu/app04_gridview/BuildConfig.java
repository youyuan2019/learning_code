/** Automatically generated file. DO NOT MODIFY */
package com.atguigu.app04_gridview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}