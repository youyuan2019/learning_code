package com.atguigu.l05_handler;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

public class AsyncTaskTestActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_async);
	}

	public void downloadApk(View v) {
		
	}

}
