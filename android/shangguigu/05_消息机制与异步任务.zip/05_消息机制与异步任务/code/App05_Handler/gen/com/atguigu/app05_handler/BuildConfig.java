/** Automatically generated file. DO NOT MODIFY */
package com.atguigu.app05_handler;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}