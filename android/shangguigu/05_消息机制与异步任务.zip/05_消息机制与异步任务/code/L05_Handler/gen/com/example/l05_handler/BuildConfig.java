/** Automatically generated file. DO NOT MODIFY */
package com.example.l05_handler;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}