/** Automatically generated file. DO NOT MODIFY */
package com.atguigu.l05_handler;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}