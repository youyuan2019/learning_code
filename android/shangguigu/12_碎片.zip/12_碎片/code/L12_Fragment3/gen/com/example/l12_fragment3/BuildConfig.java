/** Automatically generated file. DO NOT MODIFY */
package com.example.l12_fragment3;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}