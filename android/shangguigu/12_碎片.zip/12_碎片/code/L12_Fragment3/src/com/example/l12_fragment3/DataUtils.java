package com.example.l12_fragment3;

public class DataUtils {
	public static final String[] TITLES = {"title1","title2","title3","title4","title5"};
	public static final String[] DETAILS = {"This is title1","This is title2",
		"This is title3","This is title4","This is title5"};
}
