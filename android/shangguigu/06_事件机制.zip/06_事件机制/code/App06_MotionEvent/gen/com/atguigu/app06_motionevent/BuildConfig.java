/** Automatically generated file. DO NOT MODIFY */
package com.atguigu.app06_motionevent;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}