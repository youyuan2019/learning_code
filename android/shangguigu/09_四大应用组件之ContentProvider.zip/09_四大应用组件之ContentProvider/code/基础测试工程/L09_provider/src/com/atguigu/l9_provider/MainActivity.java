package com.atguigu.l9_provider;

import android.app.Activity;
import android.os.Bundle;
/**
 * 测试ContentProvider的主界面
 * @author Administrator
 *
 */
public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}
}
