/** Automatically generated file. DO NOT MODIFY */
package com.atguigu.l09_provider;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}