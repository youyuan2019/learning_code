package com.atguigu.l02_life;

import android.app.Activity;
import android.os.Bundle;

/**
 * 界面二
 * 
 * @author Administrator
 *
 */
public class SecondActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_second);
		
	}
}
