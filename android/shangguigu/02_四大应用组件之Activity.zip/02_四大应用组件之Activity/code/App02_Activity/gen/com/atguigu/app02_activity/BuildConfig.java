/** Automatically generated file. DO NOT MODIFY */
package com.atguigu.app02_activity;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}