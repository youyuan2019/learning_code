/** Automatically generated file. DO NOT MODIFY */
package com.atguigu.l02_lauchmode;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}