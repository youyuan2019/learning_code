/** Automatically generated file. DO NOT MODIFY */
package com.atguigu.app07_remoteservice;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}